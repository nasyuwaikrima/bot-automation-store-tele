module.exports = {
    botToken: '7860535102:AAFYiz_TBfgwNDdujezCMmTYiOZ9mZCmkSQ', // Isi token dari @BotFather
    ownerId: 8017894504,
    channels: ['@aboutaraXC', '@seputarinformasibotcoin'], // Username channel wajib join
    group: '@roompublikaraa', // Username grup wajib join
    notifChannel: '@allnotifpenukarancoin', // Channel laporan penukaran
    startImage: 'https://files.catbox.moe/9syrwi.jpg' // Gambar menu utama
};